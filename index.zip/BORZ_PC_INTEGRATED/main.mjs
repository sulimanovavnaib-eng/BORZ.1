
"use strict";
(async function(){
const $=id=>document.getElementById(id);
const video=$("video"), cv=$("cv"), ctx=cv.getContext("2d");
let stream=null, model=null, running=false, scanning=true, last=null, allObjects=[], map=null, marker=null, userPos=null, routeLayer=null, three=null;
let expandedDetector=null, depthEstimator=null;

const labels={person:"ЧЕЛОВЕК",chair:"СТУЛ",couch:"ДИВАН",table:"СТОЛ",laptop:"НОУТБУК","cell phone":"ТЕЛЕФОН",bottle:"БУТЫЛКА",cup:"ЧАШКА",car:"АВТОМОБИЛЬ",backpack:"РЮКЗАК",tv:"ТЕЛЕВИЗОР",keyboard:"КЛАВИАТУРА",mouse:"МЫШЬ",book:"КНИГА",dog:"СОБАКА",cat:"КОШКА",truck:"ГРУЗОВИК",bus:"АВТОБУС",motorcycle:"МОТОЦИКЛ",bicycle:"ВЕЛОСИПЕД",banana:"БАНАН",apple:"ЯБЛОКО",scissors:"НОЖНИЦЫ",clock:"ЧАСЫ",remote:"ПУЛЬТ",microwave:"МИКРОВОЛНОВКА",refrigerator:"ХОЛОДИЛЬНИК"};
const candidateLabels=["человек","лицо","одежда","обувь","рюкзак","сумка","стол","стул","диван","кровать","шкаф","дверь","окно","лампа","компьютер","ноутбук","монитор","клавиатура","мышь","телефон","наушники","камера","микрофон","телевизор","холодильник","плита","чашка","бутылка","книга","машина","мотоцикл","велосипед","автобус","грузовик","дерево","растение","собака","кошка","еда","инструмент","ключ","кошелек","часы","очки","пульт","зарядка","кабель","коробка","игрушка"];

function toast(t){const e=$("toast");e.textContent=t;e.style.display="block";clearTimeout(window.__toast);window.__toast=setTimeout(()=>e.style.display="none",2500)}
function speak(t){if(!window.speechSynthesis)return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang="ru-RU";u.rate=.96;window.speechSynthesis.speak(u)}
function addLog(role,text){const log=$("aiLog");const d=document.createElement("div");d.className="msg "+role;d.textContent=(role==="user"?"Вы: ":"BORZ: ")+text;log.appendChild(d);while(log.children.length>6)log.removeChild(log.firstChild);log.scrollTop=log.scrollHeight}
function resize(){cv.width=innerWidth*devicePixelRatio;cv.height=innerHeight*devicePixelRatio;cv.style.width=innerWidth+"px";cv.style.height=innerHeight+"px";ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)}
addEventListener("resize",()=>{resize(); if(map)map.invalidateSize()});resize();

function initMap(){
 map=L.map("map",{zoomControl:false,attributionControl:true}).setView([50.2343,11.7240],15);
 L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
 marker=L.marker([50.2343,11.7240]).addTo(map);
}
function locate(){
 if(!navigator.geolocation)return;
 navigator.geolocation.watchPosition(p=>{
   userPos=[p.coords.latitude,p.coords.longitude];
   $("gps").textContent="GPS "+userPos[0].toFixed(5)+", "+userPos[1].toFixed(5);
   marker.setLatLng(userPos); map.setView(userPos,16);
 },()=>{$("gps").textContent="GPS НЕДОСТУПЕН"},{enableHighAccuracy:true,maximumAge:10000,timeout:10000});
}

async function routeTo(destination){
 const d=destination.trim(); if(!d){toast("Введи адрес");return}
 if(!userPos){toast("Ожидаю GPS");return}
 try{
   $("routeInfo").style.display="block"; $("routeInfo").textContent="Ищу место…";
   const q=encodeURIComponent(d);
   const geo=await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=${q}`,{headers:{"Accept-Language":"ru"}});
   if(!geo.ok)throw new Error("Геокодер недоступен");
   const places=await geo.json(); if(!places.length)throw new Error("Место не найдено");
   const dest=[Number(places[0].lat),Number(places[0].lon)];
   const route=await fetch(`https://router.project-osrm.org/route/v1/driving/${userPos[1]},${userPos[0]};${dest[1]},${dest[0]}?overview=full&geometries=geojson`);
   if(!route.ok)throw new Error("Маршрутизатор недоступен");
   const rr=await route.json(); if(!rr.routes?.length)throw new Error("Маршрут не найден");
   const r=rr.routes[0];
   if(routeLayer)map.removeLayer(routeLayer);
   routeLayer=L.geoJSON(r.geometry,{style:{color:"#55eaff",weight:5,opacity:.9}}).addTo(map);
   map.fitBounds(routeLayer.getBounds(),{padding:[15,15]});
   const km=(r.distance/1000).toFixed(1), min=Math.round(r.duration/60);
   $("routeInfo").textContent=`${places[0].display_name} · ${km} км · ~${min} мин`;
   addLog("ai",`Маршрут построен: ${km} км, примерно ${min} минут.`);
 }catch(e){$("routeInfo").textContent="Ошибка: "+e.message;toast(e.message)}
}

async function camera(){
 try{
  if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;return}
  stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1920},height:{ideal:1080}},audio:false});
  video.srcObject=stream; await video.play(); $("bootText").textContent="Камера подключена"; setTimeout(()=>$("boot").classList.add("hidden"),700);
 }catch(e){$("bootText").textContent="Разреши камеру в браузере.";toast("Нет доступа к камере")}
}
function battery(){
 if(navigator.getBattery)navigator.getBattery().then(b=>{function f(){let p=Math.round(b.level*100)+"%";$("bat").textContent=p;$("batTop").textContent=p}f();b.addEventListener("levelchange",f)}).catch(()=>{});
}
function wire(){
 const c=$("wire"),x=c.getContext("2d"),w=c.clientWidth,h=c.clientHeight,d=devicePixelRatio||1;c.width=w*d;c.height=h*d;x.setTransform(d,0,0,d,0,0);x.clearRect(0,0,w,h);x.strokeStyle="#55eaff";x.lineWidth=1;
 const L=[[38,18,120,18],[38,18,38,78],[120,18,120,78],[38,78,120,78],[48,28,130,28],[48,28,48,88],[130,28,130,88],[48,88,130,88],[38,18,48,28],[120,18,130,28],[38,78,48,88],[120,78,130,88],[25,91,130,98],[25,91,16,118],[130,98,141,118],[16,118,141,118],[38,78,16,118],[120,78,141,118]];
 L.forEach(a=>{x.beginPath();x.moveTo(a[0],a[1]);x.lineTo(a[2],a[3]);x.stroke()});
 for(let y=40;y<115;y+=13){x.beginPath();x.moveTo(18,y);x.lineTo(140,y+5);x.stroke()}
}
function label(n){return labels[n]||String(n).toUpperCase()}
function estimate(p){return Math.max(.6,3.8-(p.bbox[2]/video.videoWidth)*2.7).toFixed(1)}
function drawBox(p){
 const sx=innerWidth/video.videoWidth,sy=innerHeight/video.videoHeight,b=p.bbox; const x=b[0]*sx,y=b[1]*sy,w=b[2]*sx,h=b[3]*sy;
 ctx.strokeStyle="#57f39b";ctx.lineWidth=2;ctx.strokeRect(x,y,w,h);ctx.fillStyle="#57f39b";ctx.font="bold 13px Arial";
 const txt=label(p.class)+" "+Math.round(p.score*100)+"%";ctx.fillText(txt,x,y>20?y-7:16);
}
function updateObjects(arr){
 allObjects=arr||[]; $("objList").textContent=allObjects.length?allObjects.slice(0,8).map(o=>`${label(o.class)} ${Math.round(o.score*100)}%`).join(" · "):"Список объектов: —";
}
async function detect(){
 if(!running)return;
 if(video.readyState>=2 && model && scanning){
  try{
   const arr=await model.detect(video);ctx.clearRect(0,0,innerWidth,innerHeight);updateObjects(arr);
   if(arr.length){const p=arr.slice().sort((a,b)=>b.score-a.score)[0];last=p;drawBox(p);const n=label(p.class),q=Math.round(p.score*100),dist=estimate(p);$("objName").textContent=n;$("conf").textContent=q+"%";$("statObj").textContent=n+" ("+q+"%)";$("dims").innerHTML=`РАЗМЕР (оценка)<br>В: ${Math.round(p.bbox[3]*.45)} см · Ш: ${Math.round(p.bbox[2]*.35)} см<br>Г: ${Math.round(p.bbox[2]*.30)} см<br>РАССТОЯНИЕ: ${dist} м`;$('scanLabel').style.display='block'}else{$("objName").textContent="НЕ НАЙДЕН";$("conf").textContent="—";$("statObj").textContent="NONE";$('scanLabel').style.display='none'}
  }catch(e){console.warn(e);$("aiText").textContent="CV: "+e.message}
 }
 setTimeout(()=>requestAnimationFrame(detect),180);
}
async function loadVision(){
 try{$("bootText").textContent="Загрузка быстрого зрения…";await tf.ready();model=await cocoSsd.load({base:"lite_mobilenet_v2"});running=true;$("bootText").textContent="Компьютерное зрение готово";setTimeout(()=>$("boot").classList.add("hidden"),600);detect();}
 catch(e){$("bootText").textContent="CV: "+e.message;toast("Модель зрения не загрузилась")}
}

async function loadExpandedDetector(){
 if(expandedDetector)return expandedDetector;
 $("aiText").textContent="Загружаю расширенное ИИ-зрение…";
 try{
   const {pipeline}=await import("https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1");
   expandedDetector=await pipeline("zero-shot-object-detection","onnx-community/grounding-dino-tiny-ONNX",{dtype:"q4f16"});
   return expandedDetector;
 }catch(e){toast("Расширенная модель не загрузилась: "+e.message);throw e}
}
async function expandedScan(){
 if(video.readyState<2){toast("Сначала запусти камеру");return}
 try{
   const det=await loadExpandedDetector();
   const frame=new OffscreenCanvas(640,Math.round(640*video.videoHeight/video.videoWidth));const fx=frame.getContext("2d");fx.drawImage(video,0,0,frame.width,frame.height);
   const blob=await frame.convertToBlob({type:"image/jpeg",quality:.82});
   const url=URL.createObjectURL(blob);const im=new Image();await new Promise((res,rej)=>{im.onload=res;im.onerror=rej;im.src=url});
   const res=await det(im,candidateLabels,{threshold:0.18,top_k:12});URL.revokeObjectURL(url);
   allObjects=res.map(x=>({class:x.label,score:x.score,bbox:[x.box.xmin,x.box.ymin,x.box.xmax-x.box.xmin,x.box.ymax-x.box.ymin]}));
   updateObjects(allObjects); if(res.length){const best=res[0];$("objName").textContent=best.label.toUpperCase();$("conf").textContent=Math.round(best.score*100)+"%";$("statObj").textContent=best.label.toUpperCase();$("dims").innerHTML="РАЗМЕР: ИИ-оценка\nРАССТОЯНИЕ: нет точного датчика";$("aiText").textContent=`Расширенное сканирование: найдено ${res.length} объектов.`} else $("aiText").textContent="Расширенное ИИ-зрение не нашло подходящих объектов.";
 }catch(e){$("aiText").textContent="Ошибка расширенного сканирования."}
}

async function depth3D(){
 if(video.readyState<2){toast("Сначала запусти камеру");return}
 $("model3d").style.display="block"; if(!three)init3d();
 try{
  $("model3d").querySelector(".modelTitle").textContent="BORZ · 3D ГЛУБИНА";
  const {pipeline}=await import("https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1");
  depthEstimator=depthEstimator||await pipeline("depth-estimation","onnx-community/depth-anything-v2-small",{dtype:"q4f16"});
  const frame=new OffscreenCanvas(320,Math.round(320*video.videoHeight/video.videoWidth));const fx=frame.getContext("2d");fx.drawImage(video,0,0,frame.width,frame.height);const blob=await frame.convertToBlob({type:"image/jpeg",quality:.75});const url=URL.createObjectURL(blob);const im=new Image();await new Promise((res,rej)=>{im.onload=res;im.onerror=rej;im.src=url});
  const out=await depthEstimator(im);URL.revokeObjectURL(url); buildDepthCloud(out.predicted_depth);
  $("aiText").textContent="3D-карта глубины построена. Это относительная глубина, не LiDAR.";
 }catch(e){toast("3D-глубина недоступна: "+e.message)}
}
function buildDepthCloud(tensor){
 if(!three||!tensor)return;const geom=three.userData.cloudGeom;if(geom)three.scene.remove(three.userData.cloud);const data=tensor.data;const [h,w]=tensor.dims||[128,128];const count=Math.min(9000,w*h);const step=Math.max(1,Math.floor(Math.sqrt((w*h)/count)));const pos=[];for(let y=0;y<h;y+=step){for(let x=0;x<w;x+=step){const i=y*w+x;const d=data[i]||0;const z=(d/(Math.max(...data)||1))*.9;pos.push((x/w-.5)*2,-(y/h-.5)*2,z*2)}}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));const m=new THREE.PointsMaterial({color:0x55eaff,size:.018});const cloud=new THREE.Points(g,m);three.scene.add(cloud);three.userData.cloudGeom=g;three.userData.cloud=cloud;
}
function init3d(){
 const box=$("three");three={scene:new THREE.Scene(),camera:new THREE.PerspectiveCamera(45,1,.1,100),renderer:new THREE.WebGLRenderer({alpha:true,antialias:true})};
 const scene=three.scene,cam=three.camera,r=three.renderer;cam.position.set(2,1.7,3.5);r.setPixelRatio(devicePixelRatio);r.setSize(Math.min(300,box.clientWidth||280),Math.min(300,box.clientHeight||280));box.innerHTML="";box.appendChild(r.domElement);scene.add(new THREE.AmbientLight(0xffffff,1.4));scene.add(new THREE.GridHelper(4,12,0x55eaff,0x15383e));const group=new THREE.Group();scene.add(group);
 const g=new THREE.BoxGeometry(1.35,1.4,1.05),m=new THREE.MeshBasicMaterial({color:0x55eaff,wireframe:true});const o=new THREE.Mesh(g,m);o.position.y=.8;group.add(o);for(const x of [-.55,.55])for(const z of [-.4,.4]){const cg=new THREE.CylinderGeometry(.045,.045,1.4,8),cm=new THREE.MeshBasicMaterial({color:0x55eaff});const co=new THREE.Mesh(cg,cm);co.position.set(x,.1,z);group.add(co)}cam.lookAt(0,.7,0);(function anim(){requestAnimationFrame(anim);group.rotation.y+=.008;r.render(scene,cam)})();
}

async function askAI(question){
 const q=question.trim();if(!q)return;addLog("user",q);$("aiInput").value="";$("aiText").textContent="BORZ думает…";
 const context={objects:allObjects.slice(0,12).map(o=>({label:o.class,score:o.score,bbox:o.bbox})),selected:last?{label:last.class,score:last.score,distance_m:Number(estimate(last))}:null,gps:userPos,route:$("routeInfo").textContent||null};
 try{
   const r=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({question:q,context})});
   const data=await r.json(); if(!r.ok||!data.answer)throw new Error(data.error||"AI backend unavailable");
   $("aiText").textContent=data.answer;addLog("ai",data.answer);speak(data.answer);
 }catch(e){$("aiText").textContent="BORZ: "+e.message;addLog("ai","Не удалось подключиться к локальному ИИ. Проверь, что server.py запущен и Ollama доступен.")}
}

$("cameraBtn").onclick=camera;
$("aiBtn").onclick=()=>{$("aiInput").focus();$("aiText").textContent="Задайте вопрос BORZ."};
$("searchBtn").onclick=()=>{const q=last?label(last.class):$("objName").textContent;window.open("https://www.google.com/search?q="+encodeURIComponent(q),"_blank");$("aiText").textContent="Открываю поиск: "+q};
$("scanBtn").onclick=function(){scanning=!scanning;this.classList.toggle("active",scanning);$("scanLabel").style.display=scanning?"block":"none";$("aiText").textContent=scanning?"Живое сканирование включено.":"Сканирование остановлено."};
$("mapBtn").onclick=()=>{$("mapBox").classList.toggle("hidden");setTimeout(()=>map.invalidateSize(),100)};
$("route").onclick=()=>routeTo($("dest").value);
$("open3d").onclick=depth3D;
$("close3d").onclick=()=>{$("model3d").style.display="none"};
$("sendAI").onclick=()=>askAI($("aiInput").value);
$("aiInput").addEventListener("keydown",e=>{if(e.key==="Enter")askAI($("aiInput").value)});
$("localMode").onclick=()=>{$("localMode").classList.add("active");$("browserMode").classList.remove("active");$("aiModeLabel").textContent="OLLAMA / QWEN"};
$("browserMode").onclick=()=>{$("browserMode").classList.add("active");$("localMode").classList.remove("active");$("aiModeLabel").textContent="БРАУЗЕРНЫЕ API";$("aiText").textContent="Режим браузерных функций активен."};
$("mic").onclick=()=>{const R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R){toast("Распознавание речи не поддерживается");return}const r=new R();r.lang="ru-RU";r.interimResults=false;r.onstart=()=>{$("aiText").textContent="Слушаю…"};r.onresult=e=>askAI(e.results[0][0].transcript);r.onerror=()=>toast("Не удалось распознать речь");r.start()};
$("bootText").textContent="Инициализация BORZ…";

battery();wire();initMap();locate();camera();loadVision();
})();
