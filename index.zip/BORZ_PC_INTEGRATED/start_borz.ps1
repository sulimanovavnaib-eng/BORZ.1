Set-Location -LiteralPath $PSScriptRoot
Write-Host "BORZ starting..." -ForegroundColor Cyan
Start-Process "http://127.0.0.1:8000"
python .\server.py
