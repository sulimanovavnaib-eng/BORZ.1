#!/usr/bin/env python3
import json
import os
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

ROOT = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 8000
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434/api/chat")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:7b")
SYSTEM_PROMPT = """
Ты — BORZ, персональный локальный ИИ-ассистент.
Всегда отвечай пользователю на русском языке, если пользователь не попросил другой язык.
Обращайся к пользователю как «СЭР».
Отвечай естественно, кратко и по делу.
Ты можешь использовать контекст камеры, распознанных объектов, GPS и маршрута, который передаёт интерфейс.
Не выдумывай данные, которых нет в контексте. Если точного расстояния, высоты или другого датчика нет, прямо скажи об этом.
Не утверждай, что видишь то, чего не было передано системой компьютерного зрения.
""".strip()

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def _json(self, code, payload):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/api/status":
            ok = False
            detail = None
            try:
                req = Request("http://127.0.0.1:11434/api/tags", headers={"Accept":"application/json"})
                with urlopen(req, timeout=3) as response:
                    data = json.loads(response.read().decode("utf-8"))
                models = [str(m.get("name", "")) for m in data.get("models", [])]
                ok = OLLAMA_MODEL in models
                detail = "model found" if ok else "model not found"
            except Exception as e:
                detail = str(e)
            self._json(200, {"ollama":{"ok":ok,"model":OLLAMA_MODEL,"url":OLLAMA_URL,"detail":detail}})
            return
        super().do_GET()

    def do_POST(self):
        if self.path != "/api/ai":
            self._json(404, {"error": "Not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length).decode("utf-8"))
            question = str(body.get("question", "")).strip()
            context = body.get("context", {})
            if not question:
                self._json(400, {"error": "Пустой запрос"})
                return

            context_text = json.dumps(context, ensure_ascii=False, indent=2)
            user_content = (
                "Запрос пользователя:\n" + question +
                "\n\nТекущий технический контекст BORZ:\n" + context_text
            )
            payload = {
                "model": OLLAMA_MODEL,
                "stream": False,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_content},
                ],
                "options": {"temperature": 0.25, "num_ctx": 8192},
            }
            raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            req = Request(OLLAMA_URL, data=raw, headers={"Content-Type": "application/json"}, method="POST")
            with urlopen(req, timeout=120) as response:
                result = json.loads(response.read().decode("utf-8"))
            answer = ((result.get("message") or {}).get("content") or "").strip()
            if not answer:
                raise RuntimeError("Ollama вернул пустой ответ")
            self._json(200, {"answer": answer, "model": OLLAMA_MODEL})
        except HTTPError as e:
            self._json(502, {"error": f"Ollama HTTP {e.code}"})
        except URLError:
            self._json(503, {"error": "Ollama недоступен. Убедись, что Ollama запущен в Windows."})
        except Exception as e:
            self._json(500, {"error": str(e)})

if __name__ == "__main__":
    print(f"BORZ server: http://{HOST}:{PORT}")
    print(f"Ollama: {OLLAMA_URL} | model: {OLLAMA_MODEL}")
    with ThreadingHTTPServer((HOST, PORT), Handler) as httpd:
        httpd.serve_forever()
